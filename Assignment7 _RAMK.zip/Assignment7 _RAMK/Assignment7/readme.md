
Functions:
By defining complex operations on SassScript values, functions can be reused throughout the stylesheet. For example, I created a function in _functions.scss that changes the text color based on the background color.

Variables:
To store a value in a name and use it everywhere instead of repeating the value, I used variables. I also used variables to store colors. _variables.scss contains several variables.

Nesting:
To create CSS selectors that follow the same visual hierarchy as HTML, I used nesting. The about section is an example. style.scss has more samples.

Mixins:
Styles that can be reused throughout the stylesheet can be defined with mixins. The _mixins.scss file contains examples. For instance, the 'graph-text' mixin was used to change text formatting for 'p' tags in the about, menu, and contact sections.

Interpolation:
By wrapping an expression in #{} almost anywhere in a Sass stylesheet, you can embed the result of a SassScript expression into a chunk of CSS. I used it for the text-decoration property, which is used at multiple locations.

Flexbox Layout:
For layout in one dimension, flexbox was used. In the about section and nav section, flexbox was employed. These examples can be found in style.scss.

Grid Layout:
For two-dimensional layout - rows and columns simultaneously - grid was employed. The contact and menu sections are two examples. Check out style.scss.

Placeholder Selectors:
A class selector that starts with % and isn't included in the CSS output is known as a placeholder selector. It was utilized to alter the font size, and it can be seen in _placeholder.scss.

Custom Properties:
The custom properties were used for things like color. Check out style.scss for examples.